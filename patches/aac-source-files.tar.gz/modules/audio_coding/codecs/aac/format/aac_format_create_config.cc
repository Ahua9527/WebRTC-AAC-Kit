#include "modules/audio_coding/codecs/aac/aac_format.h"

#include <algorithm>
#include <cstdint>
#include <optional>
#include <vector>

namespace webrtc {

namespace {

constexpr uint32_t kSampleRates[] = {
    96000, 88200, 64000, 48000, 44100, 32000, 24000,
    22050, 16000, 12000, 11025, 8000, 7350, 0};

constexpr uint8_t kObjectTypeAacHe = 23;
constexpr uint8_t kObjectTypeAacHev2 = 39;
constexpr uint8_t kObjectTypeAacLc = 2;

std::optional<uint8_t> FindSampleRateIndex(uint32_t sample_rate) {
  for (size_t i = 0; i < std::size(kSampleRates); ++i) {
    if (kSampleRates[i] == sample_rate) {
      return static_cast<uint8_t>(i);
    }
  }
  return std::nullopt;
}

void PushBits(uint32_t value,
              int num_bits,
              uint32_t& current_bits,
              int& bits_in_buffer,
              std::vector<uint8_t>& result) {
  if (num_bits <= 0) {
    return;
  }

  while (num_bits > 0) {
    const int bits_to_write = std::min(8 - bits_in_buffer, num_bits);
    const int shift = num_bits - bits_to_write;
    const uint32_t chunk =
        (value >> shift) & ((1u << bits_to_write) - 1u);
    current_bits = (current_bits << bits_to_write) | chunk;
    bits_in_buffer += bits_to_write;
    num_bits -= bits_to_write;
    if (bits_in_buffer == 8) {
      result.push_back(static_cast<uint8_t>(current_bits & 0xFFu));
      current_bits = 0;
      bits_in_buffer = 0;
    }
  }
}

void WriteAudioObjectType(uint8_t object_type,
                          uint32_t& current_bits,
                          int& bits_in_buffer,
                          std::vector<uint8_t>& result) {
  if (object_type < 32) {
    PushBits(object_type & 0x1Fu, 5, current_bits, bits_in_buffer, result);
  } else {
    PushBits(31, 5, current_bits, bits_in_buffer, result);
    PushBits(object_type - 32, 6, current_bits, bits_in_buffer, result);
  }
}

uint8_t EncodeSampleRate(uint32_t hz,
                         bool* explicit_rate,
                         std::vector<uint8_t>& result,
                         uint32_t& current_bits,
                         int& bits_in_buffer) {
  const std::optional<uint8_t> index = FindSampleRateIndex(hz);
  if (!index.has_value()) {
    *explicit_rate = true;
    return 0x0Fu;
  }
  *explicit_rate = false;
  return *index;
}

}  // namespace

std::vector<uint8_t> AacFormatParser::CreateAudioSpecificConfig(
    const AacConfig& config) {
  std::vector<uint8_t> result;

  const bool include_ps =
      config.ps_present || config.object_type == kObjectTypeAacHev2;
  const bool include_sbr = include_ps || config.sbr_present ||
                           config.object_type == kObjectTypeAacHe;

  const uint32_t core_sample_rate =
      include_sbr
          ? (config.core_sample_rate != 0 ? config.core_sample_rate
                                          : config.sample_rate / 2)
          : config.sample_rate;
  const uint32_t extension_sample_rate =
      include_sbr ? (config.extension_sample_rate != 0
                         ? config.extension_sample_rate
                         : config.sample_rate)
                  : 0;

  uint32_t current_bits = 0;
  int bits_in_buffer = 0;

  const uint8_t asc_object_type =
      include_ps ? 29 : (include_sbr ? 5 : config.object_type);
  WriteAudioObjectType(asc_object_type, current_bits, bits_in_buffer, result);

  bool explicit_core_rate = false;
  const uint8_t core_rate_index = EncodeSampleRate(
      core_sample_rate, &explicit_core_rate, result, current_bits,
      bits_in_buffer);
  PushBits(core_rate_index & 0x0Fu, 4, current_bits, bits_in_buffer, result);

  if (explicit_core_rate) {
    if (core_sample_rate > 0xFFFFFFu) {
      return {};
    }
    PushBits(core_sample_rate & 0xFFFFFFu, 24, current_bits, bits_in_buffer,
             result);
  }

  PushBits(config.channel_config & 0x0Fu, 4, current_bits, bits_in_buffer,
           result);

  if (include_sbr) {
    const uint32_t effective_extension_rate =
        extension_sample_rate != 0 ? extension_sample_rate : config.sample_rate;
    bool explicit_extension_rate = false;
    const uint8_t extension_rate_index = EncodeSampleRate(
        effective_extension_rate, &explicit_extension_rate, result,
        current_bits, bits_in_buffer);

    PushBits(extension_rate_index & 0x0Fu, 4, current_bits, bits_in_buffer,
             result);

    if (explicit_extension_rate) {
      if (effective_extension_rate > 0xFFFFFFu) {
        return {};
      }
      PushBits(effective_extension_rate & 0xFFFFFFu, 24, current_bits,
               bits_in_buffer, result);
    }

    const uint8_t extension_object_type =
        config.extension_object_type != 0 ? config.extension_object_type
                                          : kObjectTypeAacLc;
    WriteAudioObjectType(extension_object_type, current_bits, bits_in_buffer,
                         result);
  }

  PushBits(config.frame_length_flag & 0x1u, 1, current_bits, bits_in_buffer,
           result);
  PushBits(config.depends_on_core_coder & 0x1u, 1, current_bits,
           bits_in_buffer, result);
  if (config.depends_on_core_coder) {
    PushBits(0, 14, current_bits, bits_in_buffer, result);
  }
  PushBits(config.extension_flag & 0x1u, 1, current_bits, bits_in_buffer,
           result);

  if (bits_in_buffer > 0) {
    current_bits <<= (8 - bits_in_buffer);
    result.push_back(static_cast<uint8_t>(current_bits & 0xFFu));
  }

  return result;
}

}  // namespace webrtc
