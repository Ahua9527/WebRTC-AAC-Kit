#include "modules/audio_coding/codecs/aac/aac_format.h"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <utility>
#include <vector>

namespace webrtc {

namespace {

constexpr size_t kBitsPerByte = 8;

}  // namespace

AacFormatParser::BitReader::BitReader(const uint8_t* data, size_t length)
    : data_(data),
      length_(length),
      bit_pos_(0),
      current_byte_(0),
      bits_remaining_(0) {
  if (length_ > 0) {
    current_byte_ = data_[0];
    bits_remaining_ = 8;
  }
}

uint32_t AacFormatParser::BitReader::ReadBits(uint8_t num_bits) {
  if (num_bits == 0 || !HasMoreBits()) {
    return 0;
  }

  uint32_t result = 0;
  uint8_t bits_to_read = num_bits;

  while (bits_to_read > 0 && HasMoreBits()) {
    if (bits_remaining_ == 0) {
      size_t byte_index = bit_pos_ / kBitsPerByte;
      if (byte_index < length_) {
        current_byte_ = data_[byte_index];
        bits_remaining_ = 8;
      } else {
        break;
      }
    }

    const uint8_t bits_this_iteration =
        std::min(bits_to_read, bits_remaining_);
    const uint8_t mask = static_cast<uint8_t>((1u << bits_this_iteration) - 1u);
    const uint8_t bits_to_extract =
        (current_byte_ >> (bits_remaining_ - bits_this_iteration)) & mask;

    result = (result << bits_this_iteration) | bits_to_extract;

    bits_to_read -= bits_this_iteration;
    bits_remaining_ -= bits_this_iteration;
    bit_pos_ += bits_this_iteration;
  }

  return result;
}

std::optional<std::pair<std::vector<AuHeader>, Buffer>>
AacFormatParser::ParseRfc3640AuHeaders(const uint8_t* header_section,
                                       size_t header_section_len,
                                       uint16_t au_headers_length_bits,
                                       const Rfc3640Config& config) {
  if (!header_section || header_section_len == 0 ||
      au_headers_length_bits == 0 || config.size_length == 0) {
    return std::nullopt;
  }

  const size_t au_headers_length_bytes =
      (au_headers_length_bits + (kBitsPerByte - 1)) / kBitsPerByte;
  if (au_headers_length_bytes > header_section_len) {
    return std::nullopt;
  }

  std::vector<AuHeader> au_headers;
  BitReader reader(header_section, au_headers_length_bytes);

  size_t bits_consumed = 0;

  while (bits_consumed + config.size_length <= au_headers_length_bits) {
    AuHeader header;

    if (config.size_length > 32) {
      return std::nullopt;
    }
    header.size = reader.ReadBits(config.size_length);
    au_headers.push_back(header);
    bits_consumed += config.size_length;

    if (au_headers.size() == 1) {
      if (config.index_length > 0) {
        if (config.index_length > 32 ||
            bits_consumed + config.index_length > au_headers_length_bits) {
          return std::nullopt;
        }
        au_headers.back().index = reader.ReadBits(config.index_length);
        bits_consumed += config.index_length;
      }
    } else if (config.index_delta_length > 0) {
      if (config.index_delta_length > 32 ||
          bits_consumed + config.index_delta_length > au_headers_length_bits) {
        return std::nullopt;
      }
      au_headers.back().index_delta =
          reader.ReadBits(config.index_delta_length);
      bits_consumed += config.index_delta_length;
    }

    if (config.cts_delta_length > 0) {
      if (bits_consumed + 1 > au_headers_length_bits) {
        return std::nullopt;
      }
      au_headers.back().cts_flag = reader.ReadBits(1);
      bits_consumed += 1;
      if (au_headers.back().cts_flag) {
        if (config.cts_delta_length > 32 ||
            bits_consumed + config.cts_delta_length > au_headers_length_bits) {
          return std::nullopt;
        }
        au_headers.back().cts = reader.ReadBits(config.cts_delta_length);
        bits_consumed += config.cts_delta_length;
      }
    }

    if (config.dts_delta_length > 0) {
      if (bits_consumed + 1 > au_headers_length_bits) {
        return std::nullopt;
      }
      au_headers.back().dts_flag = reader.ReadBits(1);
      bits_consumed += 1;
      if (au_headers.back().dts_flag) {
        if (config.dts_delta_length > 32 ||
            bits_consumed + config.dts_delta_length > au_headers_length_bits) {
          return std::nullopt;
        }
        au_headers.back().dts = reader.ReadBits(config.dts_delta_length);
        bits_consumed += config.dts_delta_length;
      }
    }

    if (config.has_random_access_indicator) {
      if (bits_consumed + 1 > au_headers_length_bits) {
        return std::nullopt;
      }
      au_headers.back().random_access = reader.ReadBits(1) != 0;
      bits_consumed += 1;
    }

    if (config.has_stream_state_indicator) {
      if (bits_consumed + 1 > au_headers_length_bits) {
        return std::nullopt;
      }
      au_headers.back().stream_state = reader.ReadBits(1) != 0;
      bits_consumed += 1;
    }

    if (config.auxiliary_data_size_length > 0) {
      if (config.auxiliary_data_size_length > 32 ||
          bits_consumed + config.auxiliary_data_size_length >
              au_headers_length_bits) {
        return std::nullopt;
      }
      au_headers.back().auxiliary_data_size =
          reader.ReadBits(config.auxiliary_data_size_length);
      bits_consumed += config.auxiliary_data_size_length;
    }

    if (bits_consumed > au_headers_length_bits) {
      return std::nullopt;
    }
    if (config.index_length == 0 && au_headers.size() == 1 &&
        config.index_delta_length == 0 && config.size_length == 0) {
      return std::nullopt;
    }
  }

  const size_t audio_data_offset = au_headers_length_bytes;
  if (audio_data_offset > header_section_len) {
    return std::nullopt;
  }

  Buffer audio_data(header_section + audio_data_offset,
                    header_section_len - audio_data_offset);

  size_t total_size = 0;
  for (const auto& header : au_headers) {
    total_size += header.size;
  }
  if (total_size > audio_data.size()) {
    return std::nullopt;
  }

  return std::make_pair(std::move(au_headers), std::move(audio_data));
}

}  // namespace webrtc
