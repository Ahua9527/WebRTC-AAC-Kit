#include "modules/audio_coding/codecs/aac/aac_format.h"

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace webrtc {

namespace {

constexpr uint32_t kSampleRates[] = {
    96000, 88200, 64000, 48000, 44100, 32000, 24000,
    22050, 16000, 12000, 11025, 8000, 7350, 0};

constexpr uint8_t kObjectTypeAacMain = 1;
constexpr uint8_t kObjectTypeAacLc = 2;
constexpr uint8_t kObjectTypeAacSsr = 3;
constexpr uint8_t kObjectTypeAacLtp = 4;
constexpr uint8_t kObjectTypeAacScalable = 6;
constexpr uint8_t kObjectTypeAacHe = 23;
constexpr uint8_t kObjectTypeAacHev2 = 39;

uint8_t ReadAudioObjectType(AacFormatParser::BitReader& reader) {
  uint8_t object_type = reader.ReadBits(5);
  if (object_type == 31) {
    object_type = static_cast<uint8_t>(32 + reader.ReadBits(6));
  }
  return object_type;
}

uint8_t MapExtendedObjectType(uint8_t audio_object_type) {
  switch (audio_object_type) {
    case 5:
      return kObjectTypeAacHe;
    case 29:
      return kObjectTypeAacHev2;
    default:
      return audio_object_type;
  }
}

bool IsValidChannelConfig(uint8_t channel_config) {
  return channel_config != 0 && channel_config <= 7;
}

int LookupSampleRate(uint8_t index) {
  if (index == 15) {
    return -1;
  }
  if (index >= std::size(kSampleRates)) {
    return -1;
  }
  return static_cast<int>(kSampleRates[index]);
}

}  // namespace

std::optional<AacConfig> AacFormatParser::ParseAudioSpecificConfig(
    const std::string& config_hex) {
  std::vector<uint8_t> config_bytes = HexStringToBytes(config_hex);
  if (config_bytes.empty()) {
    return std::nullopt;
  }

  BitReader reader(config_bytes.data(), config_bytes.size());

  AacConfig config;
  config.audio_specific_config = config_bytes;

  const uint8_t raw_object_type = ReadAudioObjectType(reader);
  config.extension_object_type = 0;
  config.sbr_present = (raw_object_type == 5 || raw_object_type == 29);
  config.ps_present = (raw_object_type == 29);
  config.object_type = MapExtendedObjectType(raw_object_type);
  if (!IsSupportedProfile(config.object_type)) {
    return std::nullopt;
  }

  const uint8_t sample_rate_index = reader.ReadBits(4);
  uint32_t core_sample_rate = 0;
  if (sample_rate_index == 15) {
    core_sample_rate = reader.ReadBits(24);
  } else {
    const int sample_rate = LookupSampleRate(sample_rate_index);
    if (sample_rate <= 0) {
      return std::nullopt;
    }
    core_sample_rate = static_cast<uint32_t>(sample_rate);
  }
  config.core_sample_rate = core_sample_rate;
  config.sample_rate = core_sample_rate;
  config.extension_sample_rate = 0;

  const uint8_t channel_config = reader.ReadBits(4);
  if (!IsValidChannelConfig(channel_config)) {
    return std::nullopt;
  }
  config.channel_config = channel_config;

  if (config.sbr_present) {
    const uint8_t extension_sample_rate_index = reader.ReadBits(4);
    uint32_t extension_sample_rate = 0;
    if (extension_sample_rate_index == 15) {
      extension_sample_rate = reader.ReadBits(24);
    } else {
      const int sample_rate = LookupSampleRate(extension_sample_rate_index);
      if (sample_rate <= 0) {
        return std::nullopt;
      }
      extension_sample_rate = static_cast<uint32_t>(sample_rate);
    }
    config.extension_sample_rate = extension_sample_rate;
    config.sample_rate =
        extension_sample_rate != 0 ? extension_sample_rate : core_sample_rate;

    const uint8_t extension_object_type = ReadAudioObjectType(reader);
    config.extension_object_type = extension_object_type;
    if (extension_object_type == 29) {
      config.ps_present = true;
    }
  }

  if (config.ps_present && config.channel_config == 1) {
    config.channel_config = 2;
  }

  const uint8_t ga_object_type =
      config.sbr_present && config.extension_object_type != 0
          ? config.extension_object_type
          : config.object_type;

  if (ga_object_type == kObjectTypeAacHe ||
      ga_object_type == kObjectTypeAacHev2 ||
      ga_object_type == kObjectTypeAacLc ||
      ga_object_type == kObjectTypeAacMain ||
      ga_object_type == kObjectTypeAacSsr ||
      ga_object_type == kObjectTypeAacLtp ||
      ga_object_type == kObjectTypeAacScalable) {
    config.frame_length_flag = reader.ReadBits(1);
    config.depends_on_core_coder = reader.ReadBits(1);
    if (config.depends_on_core_coder) {
      reader.ReadBits(14);
    }
    config.extension_flag = reader.ReadBits(1);
    if (config.extension_flag && config.sbr_present) {
      reader.ReadBits(1);
    }
  }

  return config;
}

std::vector<uint8_t> AacFormatParser::HexStringToBytes(
    const std::string& hex) {
  std::vector<uint8_t> bytes;

  std::string cleaned;
  cleaned.reserve(hex.size());
  for (char c : hex) {
    if (!std::isspace(static_cast<unsigned char>(c))) {
      cleaned.push_back(static_cast<char>(std::tolower(c)));
    }
  }

  if (cleaned.length() % 2 != 0) {
    return {};
  }

  for (size_t i = 0; i < cleaned.length(); i += 2) {
    auto decode = [](char ch) -> uint8_t {
      if (ch >= 'a') {
        return static_cast<uint8_t>(ch - 'a' + 10);
      }
      return static_cast<uint8_t>(ch - '0');
    };
    const uint8_t high = decode(cleaned[i]);
    const uint8_t low = decode(cleaned[i + 1]);
    bytes.push_back(static_cast<uint8_t>((high << 4) | low));
  }

  return bytes;
}

bool AacFormatParser::IsSupportedProfile(uint8_t object_type) {
  switch (object_type) {
    case kObjectTypeAacMain:
    case kObjectTypeAacLc:
    case kObjectTypeAacSsr:
    case kObjectTypeAacLtp:
    case kObjectTypeAacHe:
    case kObjectTypeAacHev2:
    case kObjectTypeAacScalable:
      return true;
    default:
      return false;
  }
}

int AacFormatParser::GetFrameSizeMs(const AacConfig& config) {
  if (config.sbr_present || config.object_type == kObjectTypeAacHe ||
      config.object_type == kObjectTypeAacHev2) {
    return static_cast<int>((2048 * 1000) / config.sample_rate);
  }
  return static_cast<int>((1024 * 1000) / config.sample_rate);
}

int AacFormatParser::GetSamplesPerFrame(const AacConfig& config) {
  if (config.sbr_present || config.object_type == kObjectTypeAacHe ||
      config.object_type == kObjectTypeAacHev2) {
    return 2048;
  }
  return 1024;
}

int AacFormatParser::GetChannels(const AacConfig& config) {
  return config.channel_config;
}

int AacFormatParser::GetSampleRateHz(const AacConfig& config) {
  return static_cast<int>(config.sample_rate);
}

}  // namespace webrtc
