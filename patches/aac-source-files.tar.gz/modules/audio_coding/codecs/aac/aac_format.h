/*
 *  Copyright (c) 2024 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#ifndef MODULES_AUDIO_CODING_CODECS_AAC_AAC_FORMAT_H_
#define MODULES_AUDIO_CODING_CODECS_AAC_AAC_FORMAT_H_

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

#include "rtc_base/buffer.h"

namespace webrtc {

// AAC Audio-Specific-Config (ASC) structure
struct AacConfig {
  uint8_t object_type = 2;      // AAC-LC = 2
  uint32_t sample_rate = 44100; // Sample rate in Hz
  uint8_t channel_config = 1;   // Mono = 1, Stereo = 2
  uint32_t core_sample_rate = 0;      // Core AAC sample rate (before SBR)
  uint32_t extension_sample_rate = 0; // Extension sample rate (SBR/PS)
  uint8_t extension_object_type = 0;  // Underlying object type after extensions
  uint8_t frame_length_flag = 0;
  uint8_t depends_on_core_coder = 0;
  uint8_t extension_flag = 0;
  bool sbr_present = false;
  bool ps_present = false;
  std::vector<uint8_t> audio_specific_config;  // Serialized ASC (if available)
};

// RFC 3640 AU Header structure
struct AuHeader {
  uint32_t size = 0;           // AU size in bytes
  uint16_t index = 0;          // AU index
  uint16_t index_delta = 0;    // AU index delta (for subsequent AUs)
  uint16_t cts_flag = 0;       // Composition Time Stamp flag
  uint32_t cts = 0;            // Composition Time Stamp
  uint16_t dts_flag = 0;       // Decode Time Stamp flag
  uint32_t dts = 0;            // Decode Time Stamp
  bool random_access = false;  // Random Access flag
  bool stream_state = false;   // Stream state flag
  uint32_t auxiliary_data_size = 0;  // Size of following auxiliary data
};

// RFC 3640 AU header parsing configuration
struct Rfc3640Config {
  uint16_t size_length = 13;
  uint16_t index_length = 3;
  uint16_t index_delta_length = 3;
  uint16_t cts_delta_length = 0;
  uint16_t dts_delta_length = 0;
  bool has_random_access_indicator = false;
  bool has_stream_state_indicator = false;
  uint16_t auxiliary_data_size_length = 0;
};

// AU Header Section parser for RFC 3640
class AacFormatParser {
 public:
  // Parse RFC 3640 AU Header Section from incoming RTP payload
  // Returns parsed headers and the remaining audio data
  static std::optional<std::pair<std::vector<AuHeader>, Buffer>>
  ParseRfc3640AuHeaders(const uint8_t* header_section,
                        size_t header_section_len,
                        uint16_t au_headers_length_bits,
                        const Rfc3640Config& config);

  // Parse AudioSpecificConfig from SDP fmtp attribute
  static std::optional<AacConfig> ParseAudioSpecificConfig(
      const std::string& config_hex);

  // Convert hex string to bytes for config parsing
  static std::vector<uint8_t> HexStringToBytes(const std::string& hex);

  // Create AudioSpecificConfig bytes from configuration
  static std::vector<uint8_t> CreateAudioSpecificConfig(
      const AacConfig& config);

  // Validate AAC profile support
  static bool IsSupportedProfile(uint8_t object_type);

  // Get audio format info from config
  static int GetFrameSizeMs(const AacConfig& config);
  static int GetSamplesPerFrame(const AacConfig& config);
  static int GetChannels(const AacConfig& config);
  static int GetSampleRateHz(const AacConfig& config);

  // Bit-level reader for AU header parsing
  class BitReader {
   public:
    explicit BitReader(const uint8_t* data, size_t length);

    uint32_t ReadBits(uint8_t num_bits);
    bool HasMoreBits() const { return bit_pos_ < (length_ * 8); }

   private:
    const uint8_t* data_;
    size_t length_;
    size_t bit_pos_;
    uint8_t current_byte_;
    uint8_t bits_remaining_;
  };
};

}  // namespace webrtc

#endif  // MODULES_AUDIO_CODING_CODECS_AAC_AAC_FORMAT_H_
