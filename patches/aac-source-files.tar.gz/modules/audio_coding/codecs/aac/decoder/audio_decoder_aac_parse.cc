#include "modules/audio_coding/codecs/aac/audio_decoder_aac.h"

#include <algorithm>
#include <cstdint>
#include <memory>
#include <utility>
#include <vector>

#include "modules/audio_coding/codecs/aac/aac_format.h"
#include "rtc_base/logging.h"

namespace webrtc {

namespace {

class AacEncodedFrame final : public AudioDecoder::EncodedAudioFrame {
 public:
  AacEncodedFrame(AudioDecoderAac* decoder,
                  Buffer data,
                  size_t samples_per_frame)
      : decoder_(decoder),
        data_(std::move(data)),
        samples_per_frame_(samples_per_frame) {}

  size_t Duration() const override { return samples_per_frame_; }

  std::optional<DecodeResult> Decode(
      ArrayView<int16_t> decoded) const override {
    if (!decoder_) {
      return std::nullopt;
    }

    AudioDecoder::SpeechType speech_type = AudioDecoder::kSpeech;
    const size_t max_samples = decoded.size();
    const size_t max_bytes = max_samples * sizeof(int16_t);
    const int num_decoded =
        decoder_->Decode(data_.data<uint8_t>(), data_.size(),
                         decoder_->SampleRateHz(), max_bytes, decoded.data(),
                         &speech_type);

    if (num_decoded < 0) {
      return std::nullopt;
    }

    const size_t total_samples =
        static_cast<size_t>(num_decoded) * decoder_->Channels();
    return DecodeResult{total_samples, speech_type};
  }

 private:
  AudioDecoderAac* decoder_;
  Buffer data_;
  size_t samples_per_frame_;
};

}  // namespace

std::vector<AudioDecoder::ParseResult> AudioDecoderAac::ParsePayload(
    Buffer&& payload,
    uint32_t timestamp) {
  std::vector<ParseResult> results;

  if (payload.size() < 2 || has_error_) {
    if (!has_error_) {
      RTC_LOG(LS_WARNING) << "AAC payload too small";
    }
    return results;
  }

  const uint16_t au_headers_length_bits =
      (static_cast<uint16_t>(payload[0]) << 8) | payload[1];
  const uint8_t* payload_data = payload.data() + 2;
  const size_t payload_data_len = payload.size() - 2;

  if (payload_data_len == 0) {
    RTC_LOG(LS_WARNING) << "AAC payload contains no audio data";
    return results;
  }

  if (au_headers_length_bits > 0) {
    auto parse_result = AacFormatParser::ParseRfc3640AuHeaders(
        payload_data, payload_data_len, au_headers_length_bits,
        au_header_config_);

    if (!parse_result) {
      RTC_LOG(LS_WARNING) << "Failed to parse AAC AU headers";
      return results;
    }

    auto& au_headers = parse_result->first;
    Buffer& audio_data = parse_result->second;

    size_t audio_offset = 0;
    const bool has_index = config_.index_length > 0;
    const bool has_index_delta = config_.index_delta_length > 0;
    uint32_t running_index = 0;
    uint32_t base_index = 0;
    bool index_initialized = false;
    bool base_index_set = false;

    for (const auto& header : au_headers) {
      if (header.size == 0) {
        RTC_LOG(LS_WARNING) << "Skipping empty AAC AU";
        continue;
      }

      if (audio_offset + header.size > audio_data.size()) {
        RTC_LOG(LS_WARNING) << "AAC AU size exceeds payload";
        results.clear();
        return results;
      }

      Buffer frame_payload(audio_data.data() + audio_offset, header.size);
      audio_offset += header.size;

      if (header.auxiliary_data_size > 0) {
        if (audio_offset + header.auxiliary_data_size > audio_data.size()) {
          RTC_LOG(LS_WARNING) << "AAC auxiliary data exceeds payload";
          results.clear();
          return results;
        }
        audio_offset += header.auxiliary_data_size;
      }

      if (!index_initialized) {
        running_index = has_index ? header.index : 0;
        index_initialized = true;
        if (!base_index_set) {
          base_index = running_index;
          base_index_set = true;
        }
      } else if (has_index_delta) {
        running_index += header.index_delta;
      } else {
        ++running_index;
      }

      uint32_t frame_timestamp = timestamp;
      if (index_initialized) {
        const uint32_t relative_index =
            running_index >= base_index ? running_index - base_index
                                        : running_index;
        frame_timestamp += relative_index * samples_per_frame_;
      }
      if (header.dts_flag && config_.dts_delta_length > 0) {
        frame_timestamp = timestamp + header.dts;
      }
      if (header.cts_flag && config_.cts_delta_length > 0) {
        frame_timestamp =
            (header.dts_flag && config_.dts_delta_length > 0)
                ? frame_timestamp + header.cts
                : timestamp + header.cts;
      }

      auto frame = std::make_unique<AacEncodedFrame>(
          this, std::move(frame_payload), samples_per_frame_);
      results.emplace_back(frame_timestamp, 0, std::move(frame));
    }
  } else {
    Buffer frame_payload(payload_data, payload_data_len);
    auto frame = std::make_unique<AacEncodedFrame>(
        this, std::move(frame_payload), samples_per_frame_);
    results.emplace_back(timestamp, 0, std::move(frame));
  }

  return results;
}

}  // namespace webrtc
