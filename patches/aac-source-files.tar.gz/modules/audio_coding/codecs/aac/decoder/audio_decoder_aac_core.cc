#include "modules/audio_coding/codecs/aac/audio_decoder_aac.h"

#include <algorithm>

#include "modules/audio_coding/codecs/aac/aac_format.h"
#include "rtc_base/logging.h"

namespace webrtc {

AudioDecoderAac::AudioDecoderAac(const Config& config)
    : config_(config),
      sample_rate_hz_(static_cast<int>(
          config.sample_rate != 0
              ? config.sample_rate
              : (config.extension_sample_rate != 0
                     ? config.extension_sample_rate
                     : config.core_sample_rate))),
      channels_(config.ps_present && config.channels == 1 ? 2 : config.channels),
      samples_per_frame_((config.sbr_present || config.object_type == 23 ||
                          config.object_type == 39)
                             ? 2048
                             : 1024),
      au_header_config_{config.size_length,
                        config.index_length,
                        config.index_delta_length,
                        config.cts_delta_length,
                        config.dts_delta_length,
                        config.random_access_indication,
                        config.stream_state_indication,
                        config.auxiliary_data_size_length},
      buffer_pos_(0),
      buffer_samples_(0),
      has_error_(false) {
  if (sample_rate_hz_ <= 0) {
    sample_rate_hz_ = static_cast<int>(config_.core_sample_rate != 0
                                           ? config_.core_sample_rate
                                           : 44100);
  }
  if (channels_ == 0) {
    channels_ = 1;
  }
  if (!IsConfigValid()) {
    RTC_LOG(LS_ERROR) << "Invalid AAC configuration";
    has_error_ = true;
    last_error_ = "Invalid AAC configuration";
    return;
  }

  audio_buffer_.SetSize(samples_per_frame_ * channels_ * 2);
  InitializeDecoder();
}

AudioDecoderAac::~AudioDecoderAac() = default;

std::unique_ptr<AudioDecoder> AudioDecoderAac::MakeAudioDecoder(
    const Config& config) {
  return std::unique_ptr<AudioDecoder>(new AudioDecoderAac(config));
}

bool AudioDecoderAac::InitializeDecoder() {
#if defined(WEBRTC_USE_APPLE_AAC)
  if (!AacIosCapabilities::IsAacDecodingSupported()) {
    RTC_LOG(LS_ERROR) << "AAC decoding not supported on this device";
    has_error_ = true;
    last_error_ = "AAC decoding not supported on this device";
    return false;
  }

  AacConfig aac_config;
  aac_config.object_type = config_.object_type;
  aac_config.sample_rate = config_.sample_rate;
  aac_config.channel_config = config_.channels;
  aac_config.core_sample_rate = config_.core_sample_rate;
  aac_config.extension_sample_rate = config_.extension_sample_rate;
  aac_config.extension_object_type = config_.extension_object_type;
  aac_config.sbr_present = config_.sbr_present;
  aac_config.ps_present = config_.ps_present;
  if (aac_config.sbr_present) {
    if (aac_config.core_sample_rate == 0 && aac_config.sample_rate > 0) {
      aac_config.core_sample_rate = aac_config.sample_rate / 2;
    }
    if (aac_config.extension_sample_rate == 0 && aac_config.sample_rate > 0) {
      aac_config.extension_sample_rate = aac_config.sample_rate;
    }
  }

  if (!config_.audio_specific_config.empty()) {
    aac_config.audio_specific_config = config_.audio_specific_config;
  } else {
    aac_config.audio_specific_config =
        AacFormatParser::CreateAudioSpecificConfig(aac_config);
    if (aac_config.audio_specific_config.empty()) {
      RTC_LOG(LS_ERROR) << "Failed to create AudioSpecificConfig";
      has_error_ = true;
      last_error_ = "Failed to create AudioSpecificConfig";
      return false;
    }
  }

  ios_decoder_ = std::make_unique<AudioDecoderAacIos>(aac_config);
  if (!ios_decoder_->Initialize()) {
    RTC_LOG(LS_ERROR) << "Failed to initialize iOS AAC decoder";
    has_error_ = true;
    last_error_ = "Failed to initialize iOS AAC decoder";
    return false;
  }

  RTC_LOG(LS_INFO) << "AAC decoder initialized: " << config_.object_type
                   << ", " << config_.sample_rate << "Hz, "
                   << config_.channels << " channels";
  return true;
#else
  decoder_available_ = false;
  RTC_LOG(LS_WARNING) << "AAC decoder not available on this platform";
  return false;
#endif
}

void AudioDecoderAac::ClearAudioBuffer() {
  audio_buffer_.Clear();
  buffer_pos_ = 0;
  buffer_samples_ = 0;
}

bool AudioDecoderAac::IsConfigValid() const {
  return config_.object_type >= 1 && config_.object_type <= 39 &&
         config_.sample_rate >= 8000 && config_.sample_rate <= 96000 &&
         config_.channels >= 1 && config_.channels <= 8 &&
         config_.size_length >= 1 && config_.size_length <= 16 &&
         config_.index_length <= 8 && config_.index_delta_length <= 8;
}

}  // namespace webrtc
