#include "modules/audio_coding/codecs/aac/audio_decoder_aac.h"

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <optional>
#include <string>

#include "absl/strings/numbers.h"
#include "absl/strings/string_view.h"
#include "rtc_base/logging.h"

namespace webrtc {

namespace {

bool CaseInsensitiveEquals(absl::string_view lhs, absl::string_view rhs) {
  if (lhs.size() != rhs.size()) {
    return false;
  }
  for (size_t i = 0; i < lhs.size(); ++i) {
    if (std::tolower(static_cast<unsigned char>(lhs[i])) !=
        std::tolower(static_cast<unsigned char>(rhs[i]))) {
      return false;
    }
  }
  return true;
}

template <typename T>
bool ParseUnsigned(absl::string_view text, T* value) {
  static_assert(std::is_unsigned<T>::value, "T must be unsigned");
  uint64_t parsed = 0;
  if (!absl::SimpleAtoi(text, &parsed)) {
    return false;
  }
  if (parsed > std::numeric_limits<T>::max()) {
    return false;
  }
  *value = static_cast<T>(parsed);
  return true;
}

bool ParseBool(absl::string_view text, bool* value) {
  uint32_t parsed = 0;
  if (!ParseUnsigned<uint32_t>(text, &parsed)) {
    return false;
  }
  *value = parsed != 0;
  return true;
}

}  // namespace

std::optional<AudioDecoderAac::Config> AudioDecoderAac::SdpToConfig(
    const SdpAudioFormat& format) {
  if (format.name != "mpeg4-generic" && format.name != "aac") {
    return std::nullopt;
  }

  Config config;
  bool sample_rate_explicit = false;
  bool channels_explicit = false;

  auto find_param = [&](absl::string_view key) -> const std::string* {
    for (const auto& kv : format.parameters) {
      if (CaseInsensitiveEquals(kv.first, key)) {
        return &kv.second;
      }
    }
    return nullptr;
  };

  if (const std::string* object_type_param = find_param("objectType")) {
    uint32_t parsed_value = 0;
    if (ParseUnsigned<uint32_t>(*object_type_param, &parsed_value) &&
        parsed_value <= 255) {
      config.object_type = static_cast<uint8_t>(parsed_value);
    }
  }

  if (const std::string* sample_rate_param =
          find_param("samplingFrequency")) {
    uint32_t parsed_value = 0;
    if (ParseUnsigned<uint32_t>(*sample_rate_param, &parsed_value)) {
      config.sample_rate = parsed_value;
      sample_rate_explicit = true;
    }
  } else if (format.clockrate_hz > 0) {
    config.sample_rate = static_cast<uint32_t>(format.clockrate_hz);
    sample_rate_explicit = true;
  }

  if (const std::string* channels_param = find_param("channelCount")) {
    uint32_t parsed_value = 0;
    if (ParseUnsigned<uint32_t>(*channels_param, &parsed_value) &&
        parsed_value <= 255) {
      config.channels = static_cast<uint8_t>(parsed_value);
      channels_explicit = true;
    }
  } else if (format.num_channels > 0) {
    config.channels = static_cast<uint8_t>(format.num_channels);
    channels_explicit = true;
  }

  if (const std::string* config_param = find_param("config")) {
    std::optional<AacConfig> aac_config =
        AacFormatParser::ParseAudioSpecificConfig(*config_param);
    if (aac_config) {
      config.object_type = aac_config->object_type;
      config.core_sample_rate = aac_config->core_sample_rate;
      config.extension_sample_rate = aac_config->extension_sample_rate;
      config.extension_object_type = aac_config->extension_object_type;
      config.sbr_present = aac_config->sbr_present;
      config.ps_present = aac_config->ps_present;
      if (!sample_rate_explicit && aac_config->sample_rate != 0) {
        config.sample_rate = aac_config->sample_rate;
        sample_rate_explicit = true;
      } else if (aac_config->extension_sample_rate != 0) {
        config.extension_sample_rate = aac_config->extension_sample_rate;
      }
      if (!channels_explicit && aac_config->channel_config != 0) {
        config.channels = static_cast<uint8_t>(aac_config->channel_config);
        channels_explicit = true;
      } else if (aac_config->ps_present && config.channels < 2) {
        config.channels = 2;
      }
      if (config.sample_rate == 0) {
        config.sample_rate = aac_config->sample_rate;
      }
      config.audio_specific_config = aac_config->audio_specific_config;
    }
  }

  if (config.ps_present && config.channels < 2) {
    config.channels = 2;
  }
  if (config.core_sample_rate == 0) {
    config.core_sample_rate =
        config.sbr_present && config.sample_rate > 0 ? config.sample_rate / 2
                                                     : config.sample_rate;
  }
  if (config.sample_rate == 0 && config.core_sample_rate != 0) {
    config.sample_rate = config.core_sample_rate;
  }

  auto parse_optional_uint16 = [&](const std::string* param,
                                   uint16_t* target) {
    if (!param) {
      return;
    }
    uint32_t parsed_value = 0;
    if (ParseUnsigned<uint32_t>(*param, &parsed_value) &&
        parsed_value <= std::numeric_limits<uint16_t>::max()) {
      *target = static_cast<uint16_t>(parsed_value);
    }
  };

  parse_optional_uint16(find_param("sizelength"), &config.size_length);
  parse_optional_uint16(find_param("sizeLength"), &config.size_length);
  parse_optional_uint16(find_param("indexlength"), &config.index_length);
  parse_optional_uint16(find_param("indexLength"), &config.index_length);
  parse_optional_uint16(find_param("indexdeltalength"),
                        &config.index_delta_length);
  parse_optional_uint16(find_param("indexDeltaLength"),
                        &config.index_delta_length);
  parse_optional_uint16(find_param("ctsdeltalength"), &config.cts_delta_length);
  parse_optional_uint16(find_param("ctsDeltaLength"),
                        &config.cts_delta_length);
  parse_optional_uint16(find_param("dtsdeltalength"), &config.dts_delta_length);
  parse_optional_uint16(find_param("dtsDeltaLength"),
                        &config.dts_delta_length);
  parse_optional_uint16(find_param("auxiliarydatasizelength"),
                        &config.auxiliary_data_size_length);

  if (const std::string* random_access_param =
          find_param("randomaccessindication")) {
    ParseBool(*random_access_param, &config.random_access_indication);
  }

  if (const std::string* stream_state_param =
          find_param("streamstateindication")) {
    ParseBool(*stream_state_param, &config.stream_state_indication);
  }

  if (config.object_type < 1 || config.object_type > 39 ||
      config.sample_rate < 8000 || config.sample_rate > 96000 ||
      config.channels < 1 || config.channels > 8) {
    RTC_LOG(LS_WARNING) << "Invalid AAC configuration from SDP";
    return std::nullopt;
  }

  return config;
}

}  // namespace webrtc
