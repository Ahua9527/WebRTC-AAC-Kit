#include "modules/audio_coding/codecs/aac/audio_decoder_aac.h"

#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <cstring>

#include "rtc_base/logging.h"

namespace webrtc {

void AudioDecoderAac::Reset() {
#if defined(WEBRTC_USE_APPLE_AAC)
  if (ios_decoder_) {
    ios_decoder_->Reset();
  }
#endif
  ClearAudioBuffer();
  has_error_ = false;
  last_error_.clear();
}

int AudioDecoderAac::PacketDuration(const uint8_t* encoded,
                                    size_t encoded_len) const {
  if (!encoded || encoded_len == 0 || has_error_) {
    return kNotImplemented;
  }
  return samples_per_frame_;
}

int AudioDecoderAac::PacketDurationRedundant(const uint8_t* encoded,
                                             size_t encoded_len) const {
  return PacketDuration(encoded, encoded_len);
}

bool AudioDecoderAac::PacketHasFec(const uint8_t* encoded,
                                   size_t encoded_len) const {
  return false;
}

int AudioDecoderAac::SampleRateHz() const {
  return sample_rate_hz_;
}

size_t AudioDecoderAac::Channels() const {
  return channels_;
}

void AudioDecoderAac::GeneratePlc(size_t requested_samples_per_channel,
                                  BufferT<int16_t>* concealment_audio) {
  const size_t total_samples = requested_samples_per_channel * channels_;
  concealment_audio->SetSize(total_samples);
  for (size_t i = 0; i < total_samples; ++i) {
    (*concealment_audio)[i] = static_cast<int16_t>(rand() % 100 - 50);
  }
}

int AudioDecoderAac::DecodeInternal(const uint8_t* encoded,
                                    size_t encoded_len,
                                    int sample_rate_hz,
                                    int16_t* decoded,
                                    SpeechType* speech_type) {
  if (has_error_) {
    RTC_LOG(LS_ERROR) << "Decoder in error state: " << last_error_;
    return -1;
  }

  if (!encoded || encoded_len == 0 || !decoded) {
    RTC_LOG(LS_ERROR) << "Invalid decode parameters";
    return -1;
  }

  if (sample_rate_hz != sample_rate_hz_) {
    RTC_LOG(LS_WARNING) << "Sample rate mismatch: expected " << sample_rate_hz_
                        << ", got " << sample_rate_hz;
  }

  *speech_type = kSpeech;

#if defined(WEBRTC_USE_APPLE_AAC)
  if (!ios_decoder_ || !ios_decoder_->IsInitialized()) {
    RTC_LOG(LS_ERROR) << "iOS decoder not initialized";
    has_error_ = true;
    last_error_ = "iOS decoder not initialized";
    return -1;
  }

  const int decoded_samples =
      ios_decoder_->Decode(encoded, encoded_len, decoded,
                           samples_per_frame_ * channels_);
  if (decoded_samples < 0) {
    RTC_LOG(LS_ERROR) << "iOS decoder failed";
    has_error_ = true;
    last_error_ = "iOS decoder failed";
    return -1;
  }

  return decoded_samples;
#else
  RTC_LOG(LS_ERROR) << "AAC decoder not implemented for this platform";
  has_error_ = true;
  last_error_ = "AAC decoder not implemented";
  return -1;
#endif
}

void AudioDecoderAac::ProcessDecodedAudio(const int16_t* decoded_samples,
                                          size_t num_samples,
                                          int16_t* output_buffer,
                                          size_t max_output_samples,
                                          int* output_samples) {
  const size_t samples_to_copy = std::min(num_samples, max_output_samples);

  if (decoded_samples && output_buffer) {
    std::memcpy(output_buffer, decoded_samples,
                samples_to_copy * sizeof(int16_t));
  }

  *output_samples = static_cast<int>(samples_to_copy);
}

}  // namespace webrtc
