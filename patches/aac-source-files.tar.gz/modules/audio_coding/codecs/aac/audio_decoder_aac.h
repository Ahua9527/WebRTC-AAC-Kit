/*
 *  Copyright (c) 2024 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#ifndef MODULES_AUDIO_CODING_CODECS_AAC_AUDIO_DECODER_AAC_H_
#define MODULES_AUDIO_CODING_CODECS_AAC_AUDIO_DECODER_AAC_H_

#include <stddef.h>
#include <stdint.h>

#include <memory>
#include <optional>
#include <string>
#include <vector>

#include "api/audio_codecs/audio_decoder.h"
#include "api/audio_codecs/audio_format.h"
#include "modules/audio_coding/codecs/aac/aac_format.h"

#if defined(WEBRTC_USE_APPLE_AAC)
#include "modules/audio_coding/codecs/aac/ios/audio_decoder_aac_ios.h"
#endif

namespace webrtc {

class AudioDecoderAac final : public AudioDecoder {
 public:
  // Configuration structure for AAC decoder
  struct Config {
    uint8_t object_type = 2;      // AAC-LC by default
    uint32_t sample_rate = 44100; // 44.1kHz by default
    uint8_t channels = 1;         // Mono by default
    uint16_t size_length = 13;    // AU header size length
    uint16_t index_length = 3;    // AU header index length
    uint16_t index_delta_length = 3;  // AU header index delta length
    uint16_t cts_delta_length = 0;
    uint16_t dts_delta_length = 0;
    bool random_access_indication = false;
    bool stream_state_indication = false;
    uint16_t auxiliary_data_size_length = 0;
    uint32_t core_sample_rate = 0;
    uint32_t extension_sample_rate = 0;
    uint8_t extension_object_type = 0;
    bool sbr_present = false;
    bool ps_present = false;
    std::vector<uint8_t> audio_specific_config;
  };

  // Create AAC decoder with configuration
  explicit AudioDecoderAac(const Config& config);
  ~AudioDecoderAac() override;

  // Disable copy/move semantics
  AudioDecoderAac(const AudioDecoderAac&) = delete;
  AudioDecoderAac& operator=(const AudioDecoderAac&) = delete;

  // Parse configuration from SDP format
  static std::optional<Config> SdpToConfig(const SdpAudioFormat& format);

  // Create decoder instance from configuration
  static std::unique_ptr<AudioDecoder> MakeAudioDecoder(const Config& config);

  // AudioDecoder interface implementation
  std::vector<ParseResult> ParsePayload(Buffer&& payload,
                                        uint32_t timestamp) override;
  void Reset() override;
  int PacketDuration(const uint8_t* encoded, size_t encoded_len) const override;
  int PacketDurationRedundant(const uint8_t* encoded,
                              size_t encoded_len) const override;
  bool PacketHasFec(const uint8_t* encoded, size_t encoded_len) const override;
  int SampleRateHz() const override;
  size_t Channels() const override;
  void GeneratePlc(size_t requested_samples_per_channel,
                   BufferT<int16_t>* concealment_audio) override;

 protected:
  int DecodeInternal(const uint8_t* encoded,
                     size_t encoded_len,
                     int sample_rate_hz,
                     int16_t* decoded,
                     SpeechType* speech_type) override;

 private:
  // Configuration
  Config config_;
  int sample_rate_hz_;
  size_t channels_;
  int samples_per_frame_;

  // AU header configuration
  Rfc3640Config au_header_config_;

  // Platform-specific decoder implementation
#if defined(WEBRTC_USE_APPLE_AAC)
  std::unique_ptr<AudioDecoderAacIos> ios_decoder_;
#else
  // Placeholder for other platforms
  bool decoder_available_ = false;
#endif

  // Ring buffer for decoded audio to provide 10ms granularity
  BufferT<int16_t> audio_buffer_;
  size_t buffer_pos_ = 0;
  size_t buffer_samples_ = 0;

  // Error handling
  bool has_error_ = false;
  std::string last_error_;

  // Internal helper methods
  bool InitializeDecoder();
  void ProcessDecodedAudio(const int16_t* decoded_samples,
                           size_t num_samples,
                           int16_t* output_buffer,
                           size_t max_output_samples,
                           int* output_samples);
  void ClearAudioBuffer();
  bool IsConfigValid() const;
};

}  // namespace webrtc

#endif  // MODULES_AUDIO_CODING_CODECS_AAC_AUDIO_DECODER_AAC_H_
