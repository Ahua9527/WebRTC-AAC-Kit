#include "modules/audio_coding/codecs/aac/ios/audio_decoder_aac_ios.h"

#include <AudioToolbox/AudioFormat.h>

#include "modules/audio_coding/codecs/aac/aac_format.h"
#include "rtc_base/logging.h"

namespace webrtc {

AudioDecoderAacIos::AudioDecoderAacIos(const AacConfig& config)
    : config_(config),
      sample_rate_hz_(static_cast<int>(
          config.sample_rate != 0
              ? config.sample_rate
              : (config.extension_sample_rate != 0 ? config.extension_sample_rate
                                                   : config.core_sample_rate))),
      channels_(config.ps_present && config.channel_config == 1
                    ? static_cast<size_t>(2)
                    : config.channel_config),
      frame_size_ms_(AacFormatParser::GetFrameSizeMs(config)),
      samples_per_frame_(AacFormatParser::GetSamplesPerFrame(config)),
      converter_(nullptr),
      audio_specific_config_(config.audio_specific_config),
      has_error_(false) {}

AudioDecoderAacIos::~AudioDecoderAacIos() {
  if (converter_) {
    AudioConverterDispose(converter_);
    converter_ = nullptr;
  }
}

bool AudioDecoderAacIos::Initialize() {
  has_error_ = false;
  last_error_.clear();

  if (converter_) {
    AudioConverterDispose(converter_);
    converter_ = nullptr;
  }

  decoder_format_.reset();

  if (!AacIosCapabilities::IsAacDecodingSupported()) {
    last_error_ = "AAC decoding not supported on this device";
    has_error_ = true;
    return false;
  }

  if (!AacIosCapabilities::IsProfileSupported(config_.object_type)) {
    last_error_ = "AAC profile not supported";
    has_error_ = true;
    return false;
  }

  if (!AacIosCapabilities::IsSampleRateSupported(config_.sample_rate)) {
    last_error_ = "Sample rate not supported";
    has_error_ = true;
    return false;
  }

  const AudioStreamBasicDescription input_format = CreateInputFormat();
  if (input_format.mFormatID == 0) {
    last_error_ = "Failed to create input format";
    has_error_ = true;
    return false;
  }

  const AudioStreamBasicDescription output_format = CreateOutputFormat();
  if (output_format.mFormatID == 0) {
    last_error_ = "Failed to create output format";
    has_error_ = true;
    return false;
  }

  if (!ConfigureAudioConverter(input_format, output_format)) {
    last_error_ = "Failed to configure audio converter";
    has_error_ = true;
    NSLog(@"[AAC Decoder] ❌ AudioConverter configuration failed");
    return false;
  }

  // Generate ESDS format Magic Cookie for iOS AudioToolbox
  // MediaMTX's raw AudioSpecificConfig (0x11 0x90) caused OSStatus 560226676 ('!fmt' error)
  // iOS AudioToolbox requires ESDS (Elementary Stream Descriptor) format per QuickTime spec
  std::vector<uint8_t> esds_magic_cookie = GenerateESDSMagicCookie();

  const OSStatus cookie_status = AudioConverterSetProperty(
      converter_, kAudioConverterDecompressionMagicCookie,
      static_cast<UInt32>(esds_magic_cookie.size()),
      esds_magic_cookie.data());

  if (cookie_status != noErr) {
    RTC_LOG(LS_ERROR) << "Failed to set ESDS magic cookie: "
                      << OsStatusToString(cookie_status);
    NSLog(@"[AAC Decoder] ❌ Failed to set ESDS Magic Cookie, OSStatus: %d (%s)",
          (int)cookie_status, OsStatusToString(cookie_status).c_str());
    has_error_ = true;
    last_error_ = "Failed to configure ESDS magic cookie";
    return false;
  }

  NSLog(@"[AAC Decoder] ✅ ESDS Magic Cookie set successfully (%zu bytes)", esds_magic_cookie.size());

  RTC_LOG(LS_INFO) << "AudioDecoderAacIos initialized successfully: "
                   << "sample_rate=" << sample_rate_hz_ << "Hz, "
                   << "channels=" << channels_ << ", "
                   << "frame_size=" << frame_size_ms_ << "ms";

  NSLog(@"[AAC Decoder] ✅ Initialized successfully: %dHz, %dch, objectType=%d, frameSize=%dms",
        sample_rate_hz_, (int)channels_, config_.object_type, frame_size_ms_);

  return true;
}

AudioStreamBasicDescription AudioDecoderAacIos::CreateInputFormat() const {
  AudioStreamBasicDescription format = {};
  uint32_t input_sample_rate =
      config_.sbr_present && config_.core_sample_rate != 0
          ? config_.core_sample_rate
          : config_.sample_rate;
  if (input_sample_rate == 0) {
    input_sample_rate = config_.extension_sample_rate != 0
                            ? config_.extension_sample_rate
                            : static_cast<uint32_t>(sample_rate_hz_);
  }
  format.mSampleRate = input_sample_rate;
  format.mFormatID = kAudioFormatMPEG4AAC;
  format.mFormatFlags = kMPEG4Object_AAC_LC;

  // Only AAC-LC (objectType=2) is supported to match MediaMTX capabilities
  // and avoid objectType mapping complexity with iOS AudioToolbox
  switch (config_.object_type) {
    case 2:
      format.mFormatFlags = kMPEG4Object_AAC_LC;
      break;
    default:
      RTC_LOG(LS_ERROR) << "Unsupported AAC object type: "
                        << static_cast<int>(config_.object_type)
                        << " (only AAC-LC/objectType=2 is supported)";
      return {};
  }

  format.mChannelsPerFrame = channels_;

  // Force standard AAC-LC frame size (1024 samples per channel)
  // samples_per_frame_ may be calculated incorrectly (e.g., 1008 from 21ms * 48kHz)
  // but AAC-LC always uses 1024 samples/frame per ISO 14496-3
  format.mFramesPerPacket = 1024;
  NSLog(@"[AAC Decoder] 🔧 Set mFramesPerPacket=1024 (AAC-LC standard), samples_per_frame_=%d", samples_per_frame_);

  format.mBitsPerChannel = 0;
  format.mBytesPerFrame = 0;
  format.mBytesPerPacket = 0;
  format.mReserved = 0;

  return format;
}

AudioStreamBasicDescription AudioDecoderAacIos::CreateOutputFormat() const {
  AudioStreamBasicDescription format = {};
  format.mSampleRate = sample_rate_hz_;
  format.mFormatID = kAudioFormatLinearPCM;
  format.mFormatFlags = kLinearPCMFormatFlagIsSignedInteger |
                        kLinearPCMFormatFlagIsPacked;
  format.mChannelsPerFrame = channels_;
  format.mFramesPerPacket = 1;
  format.mBitsPerChannel = 16;
  format.mBytesPerFrame = (channels_ * 16) / 8;
  format.mBytesPerPacket = format.mBytesPerFrame;
  format.mReserved = 0;

  return format;
}

bool AudioDecoderAacIos::ConfigureAudioConverter(
    const AudioStreamBasicDescription& input_format,
    const AudioStreamBasicDescription& output_format) {
  decoder_format_ = input_format;

  if (converter_) {
    AudioConverterDispose(converter_);
    converter_ = nullptr;
  }

  const OSStatus status =
      AudioConverterNew(&input_format, &output_format, &converter_);
  if (status != noErr) {
    RTC_LOG(LS_ERROR) << "AudioConverterNew failed: "
                      << OsStatusToString(status);
    return false;
  }

  return true;
}

std::vector<uint8_t> AudioDecoderAacIos::GenerateESDSMagicCookie() const {
  // Generate ESDS (Elementary Stream Descriptor) atom for iOS AudioToolbox
  // Based on ISO 14496-1 and QuickTime file format specification
  // Structure: ES_Descriptor → DecoderConfigDescriptor → DecoderSpecificInfo + SLConfigDescriptor

  std::vector<uint8_t> esds;

  // AudioSpecificConfig from MediaMTX config=1190 (0x11 0x90)
  // Decoded: objectType=2 (AAC-LC), samplingFrequencyIndex=3 (48kHz), channelConfiguration=2 (stereo)
  const uint8_t audio_specific_config[] = {0x11, 0x90};
  const size_t asc_length = sizeof(audio_specific_config);

  // Calculate lengths for nested descriptors
  const size_t decoder_specific_info_length = asc_length;
  const size_t decoder_config_content_length =
      1 +  // objectTypeIndication
      1 +  // streamType
      3 +  // bufferSizeDB
      4 +  // maxBitrate
      4 +  // avgBitrate
      1 +  // DecoderSpecificInfo tag
      1 +  // DecoderSpecificInfo length
      decoder_specific_info_length;

  const size_t sl_config_content_length = 1;  // predefined
  const size_t es_descriptor_content_length =
      2 +  // ES_ID
      1 +  // flags
      1 +  // DecoderConfigDescriptor tag
      1 +  // DecoderConfigDescriptor length
      decoder_config_content_length +
      1 +  // SLConfigDescriptor tag
      1 +  // SLConfigDescriptor length
      sl_config_content_length;

  // ES_Descriptor (tag 0x03)
  esds.push_back(0x03);  // ES_DescriptorTag
  esds.push_back(static_cast<uint8_t>(es_descriptor_content_length));
  esds.push_back(0x00);  // ES_ID high byte
  esds.push_back(0x00);  // ES_ID low byte
  esds.push_back(0x00);  // flags (no URL, no OCR stream)

  // DecoderConfigDescriptor (tag 0x04)
  esds.push_back(0x04);  // DecoderConfigDescrTag
  esds.push_back(static_cast<uint8_t>(decoder_config_content_length));
  esds.push_back(0x40);  // objectTypeIndication = 0x40 (MPEG-4 Audio ISO/IEC 14496-3)
  esds.push_back(0x15);  // streamType = 0x05 (AudioStream) << 2 | 0x01 (upstream)

  // bufferSizeDB (24-bit, 6144 bytes = enough for AAC frame)
  esds.push_back(0x00);
  esds.push_back(0x18);
  esds.push_back(0x00);

  // maxBitrate (32-bit, 320000 bps for 48kHz stereo AAC-LC)
  const uint32_t max_bitrate = 320000;
  esds.push_back((max_bitrate >> 24) & 0xFF);
  esds.push_back((max_bitrate >> 16) & 0xFF);
  esds.push_back((max_bitrate >> 8) & 0xFF);
  esds.push_back(max_bitrate & 0xFF);

  // avgBitrate (32-bit, 192000 bps typical for 48kHz stereo AAC-LC)
  const uint32_t avg_bitrate = 192000;
  esds.push_back((avg_bitrate >> 24) & 0xFF);
  esds.push_back((avg_bitrate >> 16) & 0xFF);
  esds.push_back((avg_bitrate >> 8) & 0xFF);
  esds.push_back(avg_bitrate & 0xFF);

  // DecoderSpecificInfo (tag 0x05) - contains AudioSpecificConfig
  esds.push_back(0x05);  // DecoderSpecificInfoTag
  esds.push_back(static_cast<uint8_t>(decoder_specific_info_length));
  esds.push_back(audio_specific_config[0]);  // 0x11
  esds.push_back(audio_specific_config[1]);  // 0x90

  // SLConfigDescriptor (tag 0x06)
  esds.push_back(0x06);  // SLConfigDescrTag
  esds.push_back(static_cast<uint8_t>(sl_config_content_length));
  esds.push_back(0x02);  // predefined = 0x02 (reserved for use in MP4 files)

  NSLog(@"[AAC Decoder] 📦 Generated ESDS Magic Cookie: %zu bytes", esds.size());

  return esds;
}

}  // namespace webrtc
