/*
 *  Copyright (c) 2024 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#ifndef MODULES_AUDIO_CODING_CODECS_AAC_IOS_AUDIO_DECODER_AAC_IOS_H_
#define MODULES_AUDIO_CODING_CODECS_AAC_IOS_AUDIO_DECODER_AAC_IOS_H_

#include <AudioToolbox/AudioToolbox.h>
#include <AudioToolbox/AudioConverter.h>
#include <CoreAudio/CoreAudioTypes.h>

#include <memory>
#include <optional>
#include <vector>

#include "api/audio_codecs/audio_decoder.h"
#include "modules/audio_coding/codecs/aac/aac_format.h"
#include "rtc_base/buffer.h"

namespace webrtc {

// iOS AAC decoder implementation using AudioToolbox
class AudioDecoderAacIos {
 public:
  explicit AudioDecoderAacIos(const AacConfig& config);
  ~AudioDecoderAacIos();

  // Disable copy/move semantics
  AudioDecoderAacIos(const AudioDecoderAacIos&) = delete;
  AudioDecoderAacIos& operator=(const AudioDecoderAacIos&) = delete;

  // Initialize the decoder with the given configuration
  bool Initialize();

  // Decode AAC frame to PCM
  // Input: AAC encoded data
  // Output: Decoded PCM samples (16-bit signed)
  // Returns number of output samples per channel on success, -1 on error
  int Decode(const uint8_t* encoded_data,
             size_t encoded_len,
             int16_t* decoded_output,
             size_t max_output_samples);

  // Reset decoder state
  void Reset();

  // Get decoder capabilities
  int SampleRateHz() const { return sample_rate_hz_; }
  size_t Channels() const { return channels_; }
  int FrameSizeMs() const { return frame_size_ms_; }
  int SamplesPerFrame() const { return samples_per_frame_; }

  // Check if the decoder is properly initialized
  bool IsInitialized() const { return converter_ != nullptr && !has_error_; }

 private:
  // Create AudioStreamBasicDescription for AAC input format
  AudioStreamBasicDescription CreateInputFormat() const;

  // Create AudioStreamBasicDescription for PCM output format
  AudioStreamBasicDescription CreateOutputFormat() const;

  // Configure AudioConverter with the given formats
  bool ConfigureAudioConverter(const AudioStreamBasicDescription& input_format,
                               const AudioStreamBasicDescription& output_format);

  // AudioConverter input callback
  static OSStatus InputCallback(AudioConverterRef converter,
                                UInt32* num_packets,
                                AudioBufferList* buffers,
                                AudioStreamPacketDescription** packet_desc,
                                void* user_data);

  // OSStatus to error message conversion
  std::string OsStatusToString(OSStatus status) const;

  // Generate ESDS (Elementary Stream Descriptor) format Magic Cookie
  // Required by iOS AudioToolbox for AAC decoder configuration
  std::vector<uint8_t> GenerateESDSMagicCookie() const;

 private:
  // Configuration
  AacConfig config_;
  int sample_rate_hz_;
  size_t channels_;
  int frame_size_ms_;
  int samples_per_frame_;

  // AudioToolbox components
  std::optional<AudioStreamBasicDescription> decoder_format_;
  AudioConverterRef converter_;

  // Input data handling
  BufferT<uint8_t> input_buffer_;
  std::unique_ptr<AudioStreamPacketDescription> packet_desc_;
  std::vector<uint8_t> audio_specific_config_;

  // Error state
  bool has_error_;
  std::string last_error_;
};

// Runtime capability detection for AAC on iOS
class AacIosCapabilities {
 public:
  // Check if AAC decoding is supported on the current device
  static bool IsAacDecodingSupported();

  // Get supported AAC profiles
  static std::vector<uint8_t> GetSupportedProfiles();

  // Check if specific profile is supported
  static bool IsProfileSupported(uint8_t object_type);

  // Get supported sample rates
  static std::vector<uint32_t> GetSupportedSampleRates();

  // Check if specific sample rate is supported
  static bool IsSampleRateSupported(uint32_t sample_rate);

 private:
  // Cache capability detection results
  static bool capabilities_checked_;
  static bool aac_supported_;

  // Helper functions to access static data without global constructors
  static std::vector<uint8_t>& GetProfilesInternal();
  static std::vector<uint32_t>& GetSampleRatesInternal();
};

}  // namespace webrtc

#endif  // MODULES_AUDIO_CODING_CODECS_AAC_IOS_AUDIO_DECODER_AAC_IOS_H_
