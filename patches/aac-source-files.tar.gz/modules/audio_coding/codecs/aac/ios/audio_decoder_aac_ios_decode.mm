#include "modules/audio_coding/codecs/aac/ios/audio_decoder_aac_ios.h"

#include <sstream>

#include "rtc_base/logging.h"

namespace webrtc {

int AudioDecoderAacIos::Decode(const uint8_t* encoded_data,
                               size_t encoded_len,
                               int16_t* decoded_output,
                               size_t max_output_samples) {
  if (has_error_ || !converter_) {
    RTC_LOG(LS_ERROR) << "Decoder not properly initialized";
    NSLog(@"[AAC Decoder] ❌ Decode() called but decoder not initialized (has_error=%d, converter=%p)", has_error_, converter_);
    return -1;
  }

  if (!encoded_data || encoded_len == 0) {
    RTC_LOG(LS_ERROR) << "Invalid input data";
    return -1;
  }

  if (!decoded_output) {
    RTC_LOG(LS_ERROR) << "Invalid output buffer";
    return -1;
  }

  // Feed raw RFC 3640 AAC access unit directly. AudioConverter is configured
  // via the ESDS magic cookie, so ADTS wrapping is not required (and would
  // conflict with the declared stream format).
  input_buffer_.Clear();
  input_buffer_.AppendData(encoded_data, encoded_len);
  packet_desc_ = std::make_unique<AudioStreamPacketDescription>();
  packet_desc_->mStartOffset = 0;
  packet_desc_->mVariableFramesInPacket =
      static_cast<UInt32>(samples_per_frame_);
  packet_desc_->mDataByteSize = static_cast<UInt32>(encoded_len);

  UInt32 output_packets =
      static_cast<UInt32>(max_output_samples / channels_);
  const UInt32 output_data_size =
      output_packets * static_cast<UInt32>(channels_) * sizeof(int16_t);
  AudioBufferList output_buffer_list = {};
  output_buffer_list.mNumberBuffers = 1;
  output_buffer_list.mBuffers[0].mNumberChannels =
      static_cast<UInt32>(channels_);
  output_buffer_list.mBuffers[0].mDataByteSize = output_data_size;
  output_buffer_list.mBuffers[0].mData = decoded_output;

  const OSStatus status = AudioConverterFillComplexBuffer(
      converter_, InputCallback, this, &output_packets, &output_buffer_list,
      packet_desc_.get());

  if (status != noErr) {
    RTC_LOG(LS_ERROR) << "AudioConverterFillComplexBuffer failed: "
                      << OsStatusToString(status);
    NSLog(@"[AAC Decoder] ❌ AudioConverterFillComplexBuffer failed with OSStatus: %d (encoded=%zu bytes)",
          (int)status, encoded_len);
    has_error_ = true;
    last_error_ = "AudioConverterFillComplexBuffer failed";
    return -1;
  }

  input_buffer_.Clear();

  const size_t output_samples =
      output_buffer_list.mBuffers[0].mDataByteSize / sizeof(int16_t);

  // Log first successful decode only
  static bool first_decode_logged = false;
  if (!first_decode_logged) {
    NSLog(@"[AAC Decoder] ✅ First decode successful: %zu samples decoded from %zu bytes AAC payload",
          output_samples, encoded_len);
    first_decode_logged = true;
  }

  return static_cast<int>(output_samples / channels_);
}

void AudioDecoderAacIos::Reset() {
  if (converter_) {
    AudioConverterReset(converter_);
  }
  input_buffer_.Clear();
  packet_desc_.reset();
  has_error_ = false;
  last_error_.clear();
}

OSStatus AudioDecoderAacIos::InputCallback(
    AudioConverterRef converter,
    UInt32* num_packets,
    AudioBufferList* buffers,
    AudioStreamPacketDescription** packet_desc,
    void* user_data) {
  auto* decoder = static_cast<AudioDecoderAacIos*>(user_data);

  if (decoder->input_buffer_.empty()) {
    *num_packets = 0;
    return 0;
  }

  *num_packets = 1;

  if (buffers && buffers->mNumberBuffers > 0) {
    buffers->mBuffers[0].mData =
        const_cast<uint8_t*>(decoder->input_buffer_.data<uint8_t>());
    buffers->mBuffers[0].mDataByteSize =
        static_cast<UInt32>(decoder->input_buffer_.size());
    buffers->mBuffers[0].mNumberChannels =
        static_cast<UInt32>(decoder->channels_);
  }

  if (packet_desc && decoder->packet_desc_) {
    decoder->packet_desc_->mStartOffset = 0;
    decoder->packet_desc_->mDataByteSize =
        static_cast<UInt32>(decoder->input_buffer_.size());
    decoder->packet_desc_->mVariableFramesInPacket =
        static_cast<UInt32>(decoder->samples_per_frame_);
    *packet_desc = decoder->packet_desc_.get();
  }

  return noErr;
}

std::string AudioDecoderAacIos::OsStatusToString(OSStatus status) const {
  std::stringstream ss;
  ss << status;
  return ss.str();
}

}  // namespace webrtc
