#include "modules/audio_coding/codecs/aac/ios/audio_decoder_aac_ios.h"

#include <AudioToolbox/AudioFormat.h>

#include <algorithm>

#include "rtc_base/logging.h"

namespace webrtc {

bool AacIosCapabilities::capabilities_checked_ = false;
bool AacIosCapabilities::aac_supported_ = false;

std::vector<uint8_t>& AacIosCapabilities::GetProfilesInternal() {
  static auto* profiles = new std::vector<uint8_t>;
  return *profiles;
}

std::vector<uint32_t>& AacIosCapabilities::GetSampleRatesInternal() {
  static auto* sample_rates = new std::vector<uint32_t>;
  return *sample_rates;
}

bool AacIosCapabilities::IsAacDecodingSupported() {
  if (!capabilities_checked_) {
    aac_supported_ = false;

    AudioStreamBasicDescription input_format = {};
    input_format.mSampleRate = 44100;
    input_format.mFormatID = kAudioFormatMPEG4AAC;
    input_format.mFormatFlags = kMPEG4Object_AAC_LC;
    input_format.mChannelsPerFrame = 1;
    input_format.mFramesPerPacket = 1024;

    AudioStreamBasicDescription output_format = {};
    output_format.mSampleRate = 44100;
    output_format.mFormatID = kAudioFormatLinearPCM;
    output_format.mFormatFlags = kLinearPCMFormatFlagIsSignedInteger |
                                 kLinearPCMFormatFlagIsPacked;
    output_format.mChannelsPerFrame = 1;
    output_format.mFramesPerPacket = 1;
    output_format.mBitsPerChannel = 16;
    output_format.mBytesPerFrame = 2;
    output_format.mBytesPerPacket = 2;

    AudioConverterRef converter;
    const OSStatus status =
        AudioConverterNew(&input_format, &output_format, &converter);
    if (status == noErr) {
      aac_supported_ = true;
      AudioConverterDispose(converter);
    }

    auto& profiles = GetProfilesInternal();
    profiles.clear();
    profiles.push_back(2);  // AAC-LC only (matches MediaMTX capabilities)

    auto& sample_rates = GetSampleRatesInternal();
    sample_rates.clear();
    sample_rates.push_back(8000);
    sample_rates.push_back(11025);
    sample_rates.push_back(12000);
    sample_rates.push_back(16000);
    sample_rates.push_back(22050);
    sample_rates.push_back(24000);
    sample_rates.push_back(32000);
    sample_rates.push_back(44100);
    sample_rates.push_back(48000);
    sample_rates.push_back(64000);
    sample_rates.push_back(88200);
    sample_rates.push_back(96000);

    capabilities_checked_ = true;
  }

  return aac_supported_;
}

std::vector<uint8_t> AacIosCapabilities::GetSupportedProfiles() {
  IsAacDecodingSupported();
  const auto& profiles = GetProfilesInternal();
  return profiles;
}

bool AacIosCapabilities::IsProfileSupported(uint8_t object_type) {
  IsAacDecodingSupported();
  const auto& profiles = GetProfilesInternal();
  return std::find(profiles.begin(), profiles.end(), object_type) !=
         profiles.end();
}

std::vector<uint32_t> AacIosCapabilities::GetSupportedSampleRates() {
  IsAacDecodingSupported();
  const auto& sample_rates = GetSampleRatesInternal();
  return sample_rates;
}

bool AacIosCapabilities::IsSampleRateSupported(uint32_t sample_rate) {
  IsAacDecodingSupported();
  const auto& sample_rates = GetSampleRatesInternal();
  return std::find(sample_rates.begin(), sample_rates.end(), sample_rate) !=
         sample_rates.end();
}

}  // namespace webrtc
