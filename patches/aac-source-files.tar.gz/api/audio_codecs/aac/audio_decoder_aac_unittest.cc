#include "api/audio_codecs/aac/audio_decoder_aac.h"

#include <string>
#include <vector>

#include "api/audio_codecs/audio_format.h"
#include "modules/audio_coding/codecs/aac/aac_format.h"
#include "modules/audio_coding/codecs/aac/audio_decoder_aac.h"
#include "test/gtest.h"

namespace webrtc {
namespace {

constexpr uint8_t kObjectTypeAacHe = 23;
constexpr uint8_t kObjectTypeAacHev2 = 39;

std::string BytesToHex(const std::vector<uint8_t>& bytes) {
  static constexpr char kHexDigits[] = "0123456789abcdef";
  std::string result;
  result.reserve(bytes.size() * 2);
  for (uint8_t byte : bytes) {
    result.push_back(kHexDigits[(byte >> 4) & 0x0F]);
    result.push_back(kHexDigits[byte & 0x0F]);
  }
  return result;
}

AacConfig BuildHeAacConfig(bool ps) {
  AacConfig cfg;
  cfg.object_type = ps ? kObjectTypeAacHev2 : kObjectTypeAacHe;
  cfg.sample_rate = 48000;
  cfg.core_sample_rate = 24000;
  cfg.extension_sample_rate = 48000;
  cfg.channel_config = ps ? 1 : 2;
  cfg.extension_object_type = 2;  // AAC-LC core.
  cfg.sbr_present = true;
  cfg.ps_present = ps;
  return cfg;
}

TEST(AacFormatParserTest, HeAacRoundTripPreservesExtensionRates) {
  const AacConfig original = BuildHeAacConfig(/*ps=*/false);
  auto asc = AacFormatParser::CreateAudioSpecificConfig(original);
  ASSERT_FALSE(asc.empty());

  auto parsed = AacFormatParser::ParseAudioSpecificConfig(BytesToHex(asc));
  ASSERT_TRUE(parsed.has_value());
  EXPECT_EQ(parsed->object_type, kObjectTypeAacHe);
  EXPECT_TRUE(parsed->sbr_present);
  EXPECT_FALSE(parsed->ps_present);
  EXPECT_EQ(parsed->core_sample_rate, original.core_sample_rate);
  EXPECT_EQ(parsed->extension_sample_rate, original.extension_sample_rate);
  EXPECT_EQ(parsed->sample_rate, original.sample_rate);
  EXPECT_EQ(parsed->channel_config, original.channel_config);
}

TEST(AacAudioDecoderFactoryTest, SdpToConfigKeepsExplicitClockRate) {
  const AacConfig he_config = BuildHeAacConfig(/*ps=*/false);
  auto asc = AacFormatParser::CreateAudioSpecificConfig(he_config);
  ASSERT_FALSE(asc.empty());

  SdpAudioFormat format("mpeg4-generic", 48000, 2);
  format.parameters["config"] = BytesToHex(asc);
  format.parameters["objectType"] = "23";
  format.parameters["samplingFrequency"] = "48000";
  format.parameters["channelCount"] = "2";
  format.parameters["sizelength"] = "13";
  format.parameters["indexlength"] = "3";
  format.parameters["indexdeltalength"] = "3";

  auto api_config = AacAudioDecoderFactory::SdpToConfig(format);
  ASSERT_TRUE(api_config.has_value());
  EXPECT_EQ(api_config->sample_rate, 48000u);
  EXPECT_EQ(api_config->core_sample_rate, 24000u);
  EXPECT_TRUE(api_config->sbr_present);
  EXPECT_FALSE(api_config->ps_present);

  auto module_config = AudioDecoderAac::SdpToConfig(format);
  ASSERT_TRUE(module_config.has_value());
  EXPECT_EQ(module_config->sample_rate, 48000u);
  EXPECT_EQ(module_config->core_sample_rate, 24000u);
  EXPECT_TRUE(module_config->sbr_present);
  EXPECT_FALSE(module_config->ps_present);
}

TEST(AacAudioDecoderFactoryTest, HeAacV2PromotesStereoChannels) {
  AacConfig ps_config = BuildHeAacConfig(/*ps=*/true);
  auto asc = AacFormatParser::CreateAudioSpecificConfig(ps_config);
  ASSERT_FALSE(asc.empty());

  SdpAudioFormat format("mpeg4-generic", 48000, 1);
  format.parameters["config"] = BytesToHex(asc);
  format.parameters["objectType"] = "39";
  format.parameters["samplingFrequency"] = "48000";
  format.parameters["channelCount"] = "1";
  format.parameters["sizelength"] = "13";
  format.parameters["indexlength"] = "3";
  format.parameters["indexdeltalength"] = "3";

  auto api_config = AacAudioDecoderFactory::SdpToConfig(format);
  ASSERT_TRUE(api_config.has_value());
  EXPECT_EQ(static_cast<int>(api_config->channels), 2);
  EXPECT_TRUE(api_config->ps_present);
  EXPECT_EQ(api_config->core_sample_rate, 24000u);
  EXPECT_EQ(api_config->extension_sample_rate, 48000u);

  auto module_config = AudioDecoderAac::SdpToConfig(format);
  ASSERT_TRUE(module_config.has_value());
  EXPECT_EQ(static_cast<int>(module_config->channels), 2);
  EXPECT_TRUE(module_config->sbr_present);
  EXPECT_TRUE(module_config->ps_present);
  EXPECT_EQ(module_config->core_sample_rate, 24000u);
  EXPECT_EQ(module_config->extension_sample_rate, 48000u);
}

}  // namespace
}  // namespace webrtc
