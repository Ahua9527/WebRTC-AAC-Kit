/*
 *  Copyright (c) 2024 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#include "api/audio_codecs/aac/audio_decoder_aac.h"

#include <algorithm>
#include <map>
#include <sstream>
#include <string>

#include "api/audio_codecs/audio_decoder_factory_template.h"
#include "modules/audio_coding/codecs/aac/aac_format.h"
#include "modules/audio_coding/codecs/aac/audio_decoder_aac.h"
#include "api/scoped_refptr.h"
#include "rtc_base/logging.h"
#include "rtc_base/ref_counted_object.h"

namespace webrtc {

// Supported AAC configurations
namespace {
constexpr uint32_t kDefaultSampleRates[] = {
    8000, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000, 64000, 88200, 96000};

constexpr uint8_t kSupportedObjectTypes[] = {
    2,  // AAC-LC (iOS AudioToolbox supported)
    // Only AAC-LC is supported to match MediaMTX capabilities
    // HE-AAC variants (5, 29) require additional objectType mapping complexity
};

// Standard SDP parameters for AAC
const std::map<std::string, std::string>& GetDefaultSdpParameters() {
  static const std::map<std::string, std::string>* kDefaultSdpParameters =
      new std::map<std::string, std::string>{
    {"streamType", "5"},        // Audio
    {"profile-level-id", "1"},  // Default profile level
    {"mode", "AAC-hbr"},        // High Bitrate AAC
    {"sizelength", "13"},
    {"indexlength", "3"},
    {"indexdeltalength", "3"},
  };
  return *kDefaultSdpParameters;
}

// Helper function to parse string to integer with validation
bool ParseInt(const std::string& str, int* result) {
  // Simple implementation without exceptions
  if (str.empty()) {
    return false;
  }

  *result = 0;
  for (char c : str) {
    if (c < '0' || c > '9') {
      return false;
    }
    *result = *result * 10 + (c - '0');
  }

  return true;
}

}  // namespace

// AacAudioDecoderFactory implementation
std::optional<AacAudioDecoderFactory::Config> AacAudioDecoderFactory::SdpToConfig(
    const SdpAudioFormat& format) {
  // Check format name
  if (format.name != "mpeg4-generic" && format.name != "aac") {
    RTC_LOG(LS_WARNING) << "Unsupported codec format: " << format.name;
    return std::nullopt;
  }

  Config config;

  bool sample_rate_explicit = false;
  bool channels_explicit = false;

  // Parse clock rate
  if (format.clockrate_hz > 0) {
    config.sample_rate = static_cast<uint32_t>(format.clockrate_hz);
    sample_rate_explicit = true;
  }

  // Parse number of channels
  if (format.num_channels > 0) {
    config.channels = static_cast<uint8_t>(format.num_channels);
    channels_explicit = true;
  }

  // Parse SDP parameters
  for (const auto& param : format.parameters) {
    std::string key = param.first;
    std::transform(key.begin(), key.end(), key.begin(),
                   [](unsigned char c) { return std::tolower(c); });
    const std::string& value = param.second;

    if (key == "objecttype") {
      int object_type;
      if (ParseInt(value, &object_type)) {
        config.object_type = static_cast<uint8_t>(object_type);
      }
    } else if (key == "samplingfrequency") {
      int sample_rate;
      if (ParseInt(value, &sample_rate)) {
        config.sample_rate = static_cast<uint32_t>(sample_rate);
        sample_rate_explicit = true;
      }
    } else if (key == "channelcount") {
      int channels;
      if (ParseInt(value, &channels)) {
        config.channels = static_cast<uint8_t>(channels);
        channels_explicit = true;
      }
    } else if (key == "config") {
      config.config_hex = value;
      config.audio_specific_config = AacFormatParser::HexStringToBytes(value);
    } else if (key == "sizelength") {
      int size_length;
      if (ParseInt(value, &size_length)) {
        config.size_length = static_cast<uint16_t>(size_length);
      }
    } else if (key == "indexlength") {
      int index_length;
      if (ParseInt(value, &index_length)) {
        config.index_length = static_cast<uint16_t>(index_length);
      }
    } else if (key == "indexdeltalength") {
      int index_delta_length;
      if (ParseInt(value, &index_delta_length)) {
        config.index_delta_length = static_cast<uint16_t>(index_delta_length);
      }
    } else if (key == "ctsdeltalength") {
      int cts_delta_length;
      if (ParseInt(value, &cts_delta_length)) {
        config.cts_delta_length =
            static_cast<uint16_t>(cts_delta_length);
      }
    } else if (key == "dtsdeltalength") {
      int dts_delta_length;
      if (ParseInt(value, &dts_delta_length)) {
        config.dts_delta_length =
            static_cast<uint16_t>(dts_delta_length);
      }
    } else if (key == "randomaccessindication") {
      int random_access;
      if (ParseInt(value, &random_access)) {
        config.random_access_indication = random_access != 0;
      }
    } else if (key == "streamstateindication") {
      int stream_state;
      if (ParseInt(value, &stream_state)) {
        config.stream_state_indication = stream_state != 0;
      }
    } else if (key == "auxiliarydatasizelength") {
      int auxiliary_length;
      if (ParseInt(value, &auxiliary_length)) {
        config.auxiliary_data_size_length =
            static_cast<uint16_t>(auxiliary_length);
      }
    }
  }

  // Parse AudioSpecificConfig if provided
  if (!config.config_hex.empty()) {
    auto aac_config = AacFormatParser::ParseAudioSpecificConfig(config.config_hex);
    if (aac_config) {
      config.object_type = aac_config->object_type;
      config.core_sample_rate = aac_config->core_sample_rate;
      config.extension_sample_rate = aac_config->extension_sample_rate;
      config.extension_object_type = aac_config->extension_object_type;
      config.sbr_present = aac_config->sbr_present;
      config.ps_present = aac_config->ps_present;
      if (!sample_rate_explicit && aac_config->sample_rate != 0) {
        config.sample_rate = aac_config->sample_rate;
        sample_rate_explicit = true;
      } else if (aac_config->extension_sample_rate != 0) {
        config.extension_sample_rate = aac_config->extension_sample_rate;
      }
      if (!channels_explicit && aac_config->channel_config != 0) {
        config.channels = static_cast<uint8_t>(aac_config->channel_config);
        channels_explicit = true;
      } else if (aac_config->ps_present && config.channels < 2) {
        config.channels = 2;
      }
      if (config.sample_rate == 0) {
        config.sample_rate = aac_config->sample_rate;
      }
      config.audio_specific_config = aac_config->audio_specific_config;
    } else {
      RTC_LOG(LS_WARNING) << "Failed to parse AudioSpecificConfig: " << config.config_hex;
    }
  }

  if (config.ps_present && config.channels < 2) {
    config.channels = 2;
  }
  if (config.core_sample_rate == 0) {
    config.core_sample_rate =
        config.sbr_present && config.sample_rate > 0 ? config.sample_rate / 2
                                                     : config.sample_rate;
  }
  if (config.sample_rate == 0 && config.core_sample_rate != 0) {
    config.sample_rate = config.core_sample_rate;
  }

  // Validate final configuration
  if (!config.IsOk()) {
    RTC_LOG(LS_WARNING) << "Invalid AAC configuration from SDP";
    return std::nullopt;
  }

  RTC_LOG(LS_INFO) << "Parsed AAC config: objectType=" << static_cast<int>(config.object_type)
                   << ", sampleRate=" << config.sample_rate
                   << ", channels=" << static_cast<int>(config.channels);

  return config;
}

void AacAudioDecoderFactory::AppendSupportedDecoders(std::vector<AudioCodecSpec>* specs) {
  // Create specs for common AAC configurations
  for (uint32_t sample_rate : kDefaultSampleRates) {
    for (uint8_t object_type : kSupportedObjectTypes) {
      for (uint8_t channels = 1; channels <= 2; ++channels) {
        Config config;
        config.object_type = object_type;
        config.sample_rate = sample_rate;
        config.channels = channels;

        if (config.IsOk()) {
          // Create SdpAudioFormat
          SdpAudioFormat format("mpeg4-generic",
                               static_cast<int>(config.sample_rate),
                               config.channels);

          // Add standard SDP parameters
          format.parameters = GetDefaultSdpParameters();

          // Add configuration-specific parameters
          std::stringstream object_type_str;
          object_type_str << static_cast<int>(config.object_type);
          format.parameters["objectType"] = object_type_str.str();

          if (config.sample_rate != 44100) {  // Only include if not default
            std::stringstream sample_rate_str;
            sample_rate_str << config.sample_rate;
            format.parameters["samplingFrequency"] = sample_rate_str.str();
          }

          if (config.channels != 1) {  // Only include if not default
            std::stringstream channels_str;
            channels_str << static_cast<int>(config.channels);
            format.parameters["channelCount"] = channels_str.str();
          }

          // Add AU header configuration
          std::stringstream size_length_str;
          size_length_str << config.size_length;
          format.parameters["sizelength"] = size_length_str.str();

          std::stringstream index_length_str;
          index_length_str << config.index_length;
          format.parameters["indexlength"] = index_length_str.str();

          std::stringstream index_delta_length_str;
          index_delta_length_str << config.index_delta_length;
          format.parameters["indexdeltalength"] = index_delta_length_str.str();

          // Create AudioCodecSpec
          AudioCodecSpec spec{
            std::move(format),
            AudioCodecInfo(static_cast<int>(config.sample_rate),
                           config.channels,
                           0)  // Default bitrate
          };

          specs->push_back(std::move(spec));
        }
      }
    }
  }
}

std::unique_ptr<AudioDecoder> AacAudioDecoderFactory::MakeAudioDecoder(
    const Config& config,
    std::optional<AudioCodecPairId> codec_pair_id,
    const FieldTrialsView* field_trials) {
  if (!config.IsOk()) {
    RTC_LOG(LS_ERROR) << "Invalid AAC decoder configuration";
    return nullptr;
  }

  // Convert to AudioDecoderAac::Config
  AudioDecoderAac::Config decoder_config;
  decoder_config.object_type = config.object_type;
  decoder_config.sample_rate = config.sample_rate;
  decoder_config.channels = config.channels;
  decoder_config.size_length = config.size_length;
  decoder_config.index_length = config.index_length;
  decoder_config.index_delta_length = config.index_delta_length;
  decoder_config.cts_delta_length = config.cts_delta_length;
  decoder_config.dts_delta_length = config.dts_delta_length;
  decoder_config.random_access_indication = config.random_access_indication;
  decoder_config.stream_state_indication = config.stream_state_indication;
  decoder_config.auxiliary_data_size_length = config.auxiliary_data_size_length;
  decoder_config.core_sample_rate = config.core_sample_rate;
  decoder_config.extension_sample_rate = config.extension_sample_rate;
  decoder_config.extension_object_type = config.extension_object_type;
  decoder_config.sbr_present = config.sbr_present;
  decoder_config.ps_present = config.ps_present;
  decoder_config.audio_specific_config = config.audio_specific_config;

  return AudioDecoderAac::MakeAudioDecoder(decoder_config);
}

// Helper function to create AAC decoder factory
webrtc::scoped_refptr<AudioDecoderFactory> CreateAacAudioDecoderFactory() {
  return CreateAudioDecoderFactory<AacAudioDecoderFactory>();
}

}  // namespace webrtc
